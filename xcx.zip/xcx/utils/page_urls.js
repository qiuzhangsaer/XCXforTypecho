//页面地址合集
module.exports = {
	index: 'pages/index/index',
	ranking:'pages/ranking/index',
	user:'pages/user/index',
	detail:'pages/detail/index'
}
